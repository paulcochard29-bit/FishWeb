
# FishingJob — Maquette HTML (multi-pages)

Pages incluses :
- `index.html` — Homepage (recherche, KPIs, offres en vedette)
- `results.html` — Résultats de recherche (cartes d’offres)
- `job.html` — Fiche offre (détails, exigences, postuler)
- `company.html` — Fiche Armateur (flotte, visuel carte AIS, offres récentes)
- `dashboard-recruiter.html` — Tableau de bord Armateur (stats + annonces)
- `dashboard-seafarer.html` — Tableau de bord Marin (profil + alertes + candidatures)

Design :
- Thème sombre maritime, accents cyan, typographie Inter
- Composants réutilisables : cartes, panneaux, badges, tableaux, boutons

Utilisation :
- Ouvrez `index.html` (ou n’importe quelle page) dans votre navigateur / iPad (via Fichiers).
- Tout est responsive (desktop → mobile).

Note :
- Cette maquette est purement front (HTML/CSS). Pour la version **AIS connectée**, utilisez le pack que je vous ai déjà fourni.
